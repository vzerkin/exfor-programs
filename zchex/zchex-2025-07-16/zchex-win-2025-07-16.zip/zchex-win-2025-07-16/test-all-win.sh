rm zchex.tto2
rm *.err
./zchexw.exe x.x4                2>>zchex.tto2
./zchexw.exe o2.x4               2>>zchex.tto2
./zchexw.exe o1.x4               2>>zchex.tto2
./zchexw.exe e1943.x4            2>>zchex.tto2
./zchexw.exe aa.x4               2>>zchex.tto2
./zchexw.exe g18.x4              2>>zchex.tto2
./zchexw.exe a.x4                2>>zchex.tto2
./zchexw.exe na2l.x4             2>>zchex.tto2
./zchexw.exe o1728.txt           2>>zchex.tto2
./zchexw.exe mm1.x4              2>>zchex.tto2
./zchexw.exe 41110001-x4.txt     2>>zchex.tto2
./zchexw.exe 32694001-x4.txt     2>>zchex.tto2
./zchexw.exe 00001001-x4.txt     2>>zchex.tto2
./zchexw.exe nao4.x4             2>>zchex.tto2
./zchexw.exe nao5.x4             2>>zchex.tto2
./zchexw.exe nao6.x4             2>>zchex.tto2
./zchexw.exe 30448002-x4.txt     2>>zchex.tto2
./zchexw.exe 33080002.x4         2>>zchex.tto2
./zchexw.exe t0294001x4.txt      2>>zchex.tto2
./zchexw.exe d4048002.x4         2>>zchex.tto2
./zchexw.exe 31788.txt           2>>zchex.tto2
./zchexw.exe f1378.txt t         2>>zchex.tto2
./zchexw.exe O0226015.x4         2>>zchex.tto2
./zchexw.exe prelim.1470         2>>zchex.tto2
./zchexw.exe 33143.x4            2>>zchex.tto2
./zchexw.exe 11748020.x4 T  y    2>>zchex.tto2
./zchexw.exe E1877002.x4 "" y    2>>zchex.tto2
./zchexw.exe 31796001.x4         2>>zchex.tto2
./zchexw.exe O0790.x4            2>>zchex.tto2
./zchexw.exe 41576008.x4         2>>zchex.tto2
./zchexw.exe 14332.x4            2>>zchex.tto2
./zchexw.exe 32699.x4            2>>zchex.tto2
./zchexw.exe 22073.x4            2>>zchex.tto2
./zchexw.exe 23327006.x4         2>>zchex.tto2
./zchexw.exe 21564002.x4         2>>zchex.tto2
./zchexw.exe 10053003.x4         2>>zchex.tto2
./zchexw.exe G4012002.x4         2>>zchex.tto2
./zchexw.exe 14672003.x4         2>>zchex.tto2
./zchexw.exe 11105.x4            2>>zchex.tto2
./zchexw.exe 11722rev.txt        2>>zchex.tto2
./zchexw.exe minus.x4            2>>zchex.tto2
./zchexw.exe zero.x4             2>>zchex.tto2
./zchexw.exe dat-err0.x4         2>>zchex.tto2
cat *.err >___allerr.txt
echo ___Program errors file: zchex.tto2 >>___allerr.txt
cat zchex.tto2 >>___allerr.txt
echo ___Program errors file: end >>___allerr.txt
