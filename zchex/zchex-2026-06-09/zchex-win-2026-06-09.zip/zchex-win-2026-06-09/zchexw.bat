@rem
@rem	Program:	zchexw.bat
@rem	Author:		Viktor Zerkin, V.Zerkin@iaea.org
@rem	Last modified:	31-Mar-2010
@rem	Organization:	Nuclear Data Section
@rem			International Atomic Energy Agency (IAEA)
@rem			Wagramer Strasse 5, P.O.Box 100, A-1400
@rem			Vienna, Austria
@rem	Property of:	International Atomic Energy Agency
@rem	Project:	Multi-platform Nuclear Reaction Databases
@rem	Usage:		freely, with proper acknolegement to the IAEA and author
@rem	Note:		this is non-commercial software and it comes with
@rem			NO WARRANTY
@rem
@cls
@echo.
@echo.
@echo  Nuclear Data Section
@echo  International Atomic Energy Agency
@echo  Vienna, 2010
@echo.
@echo  Run ZCHEX: program checking EXFOR formatted file.......
@echo.
@echo on
@set  inpFile=%1
@set  outFile="%~dpnx1.err"
@echo File name:   %inpFile%
@echo Output file: %outFile%

@rem To use program in the TRANS-mode: remove @rem from 2 following lines
@rem @set  dataType=T
@rem @echo Data type: %dataType%

@rem pause

@echo par0=%0
@echo par1=%1
@echo.
cd /D "%~dp0"
@if exist %outFile% del %outFile%
    zchexw.exe %inpFile% %dataType%
@echo.
if exist %outFile% start notepad %outFile%
pause
